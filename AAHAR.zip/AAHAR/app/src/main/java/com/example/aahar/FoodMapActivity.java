package com.example.aahar;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class FoodMapActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_map);
    }
}
