package com.example.aahar;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class RequestFoodActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_food); // Make sure this XML file exists
    }
}
