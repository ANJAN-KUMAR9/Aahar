package com.example.aahar; // ✅ Corrected package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etLoginEmail, etLoginPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Your correct XML file

        etLoginEmail = findViewById(R.id.etLoginEmail);
        etLoginPassword = findViewById(R.id.etLoginPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etLoginEmail.getText().toString().trim();
                String password = etLoginPassword.getText().toString().trim();

                if (!email.isEmpty() && !password.isEmpty()) {
                    // ✅ Start NextActivity after successful login
                    Intent intent = new Intent(LoginActivity.this, NextActivity.class);
                    startActivity(intent);
                } else {
                    // ❌ Show error if fields are empty
                    etLoginEmail.setError("Enter Email");
                    etLoginPassword.setError("Enter Password");
                }
            }
        });

    }
}
