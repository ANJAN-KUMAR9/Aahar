package com.example.aahar; // Your correct package
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

public class NextActivity extends AppCompatActivity {

    Button btnDonate, btnReceive, btnFoodMap, btnHistory, btnAbout, btnFoodDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next); // Linked to the correct XML

        btnDonate = findViewById(R.id.btnDonate); // find the Donate button by ID

        btnDonate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Here you keep the intent
                Intent intent = new Intent(NextActivity.this, DonateActivity.class);
                startActivity(intent);
            }
        });
        btnReceive = findViewById(R.id.btnReceive);
        btnFoodMap = findViewById(R.id.btnFoodMap);
        btnHistory = findViewById(R.id.btnHistory);
        btnAbout = findViewById(R.id.btnAbout);
        btnFoodDetails = findViewById(R.id.btnFoodDetails);

        btnDonate.setOnClickListener(v -> Toast.makeText(this, "Donate Clicked", Toast.LENGTH_SHORT).show());
        btnReceive.setOnClickListener(v -> Toast.makeText(this, "Receive Clicked", Toast.LENGTH_SHORT).show());
        btnFoodMap.setOnClickListener(v -> Toast.makeText(this, "Food Map Clicked", Toast.LENGTH_SHORT).show());
        btnHistory.setOnClickListener(v -> Toast.makeText(this, "History Clicked", Toast.LENGTH_SHORT).show());
        btnAbout.setOnClickListener(v -> Toast.makeText(this, "About AAHAR Clicked", Toast.LENGTH_SHORT).show());
        btnFoodDetails.setOnClickListener(v -> Toast.makeText(this, "Food Details Clicked", Toast.LENGTH_SHORT).show());
    }
}
