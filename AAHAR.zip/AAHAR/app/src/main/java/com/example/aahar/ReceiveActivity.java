package com.example.aahar;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReceiveActivity extends AppCompatActivity {

    CheckBox checkRice, checkBread, checkFruits, checkWater;
    Button btnSubmitRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive);

        checkRice = findViewById(R.id.check_rice);
        checkBread = findViewById(R.id.check_bread);
        checkFruits = findViewById(R.id.check_fruits);
        checkWater = findViewById(R.id.check_water);
        btnSubmitRequest = findViewById(R.id.btnSubmitRequest);

        btnSubmitRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder selectedItems = new StringBuilder("Requested: ");
                boolean isItemSelected = false;

                if (checkRice.isChecked()) {
                    selectedItems.append("Rice, ");
                    isItemSelected = true;
                }
                if (checkBread.isChecked()) {
                    selectedItems.append("Bread, ");
                    isItemSelected = true;
                }
                if (checkFruits.isChecked()) {
                    selectedItems.append("Fruits, ");
                    isItemSelected = true;
                }
                if (checkWater.isChecked()) {
                    selectedItems.append("Water, ");
                    isItemSelected = true;
                }

                // Remove the last comma and space
                if (isItemSelected) {
                    selectedItems.setLength(selectedItems.length() - 2); // remove last comma and space
                }

                if (!isItemSelected) {
                    Toast.makeText(ReceiveActivity.this, "Please select at least one item.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ReceiveActivity.this, selectedItems.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        Button btnPrevious = findViewById(R.id.btnPrevious);
        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go back to the previous screen (e.g., MainActivity)
                finish(); // Finishes the current activity and returns to the previous one
            }
        });

        // Next Button
        Button btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the ConfirmationActivity
                Intent intent = new Intent(ReceiveActivity.this, ConfirmationActivity.class);
                startActivity(intent);
            }
        });
    }
}
