package com.example.aahar; // ✅ Use your correct package name

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DonateActivity extends AppCompatActivity {

    EditText etFoodItem, etQuantity, etLocation;
    Button btnSubmitDonation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate); // ✅ make sure your XML file is named activity_donate.xml

        // Link UI elements with Java
        etFoodItem = findViewById(R.id.etFoodItem);
        etQuantity = findViewById(R.id.etQuantity);
        etLocation = findViewById(R.id.etLocation);
        btnSubmitDonation = findViewById(R.id.btnSubmitDonation);

        // Set what happens when the user clicks the button
        btnSubmitDonation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String foodItem = etFoodItem.getText().toString().trim();
                String quantity = etQuantity.getText().toString().trim();
                String location = etLocation.getText().toString().trim();

                if (!foodItem.isEmpty() && !quantity.isEmpty() && !location.isEmpty()) {
                    // Show a success message
                    Toast.makeText(DonateActivity.this,
                            "Donation Submitted:\nItem: " + foodItem +
                                    "\nQuantity: " + quantity +
                                    "\nLocation: " + location,
                            Toast.LENGTH_LONG).show();

                    // (Optional) Clear the fields
                    etFoodItem.setText("");
                    etQuantity.setText("");
                    etLocation.setText("");
                } else {
                    Toast.makeText(DonateActivity.this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
