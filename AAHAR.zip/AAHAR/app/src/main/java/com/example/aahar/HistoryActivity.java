package com.example.aahar;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    TextView tvOrderHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history); // XML file name

        tvOrderHistory = findViewById(R.id.tvOrderHistory);

        // Example static data (replace with real data later)
        String[] orders = {
                "5kg Rice donated on 15 Apr",
                "3kg Fruits received on 10 Apr",
                "2kg Vegetables donated on 05 Apr"
        };

        // Display the last order (most recent)
        String lastOrder = orders[orders.length - 1];

        // Display it in the TextView
        tvOrderHistory.setText("Last Order: \n" + lastOrder);
    }
}
